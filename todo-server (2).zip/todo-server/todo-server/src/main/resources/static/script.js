const input = document.getElementById('todoInput');
const addBtn = document.getElementById('addBtn');
const todoList = document.getElementById('todoList');

// 1. 페이지 로드 시 서버에서 목록 가져오기
window.onload = loadTodos;

async function loadTodos() {
    try {
        const response = await fetch('http://localhost:8080/api/todos');
        const todos = await response.json();

        todoList.innerHTML = ''; // 기존 목록 초기화
        todos.forEach(todo => {
            createTodoElement(todo);
        });
    } catch (error) {
        console.error("목록 불러오기 실패:", error);
    }
}

// 2. 서버에 새 할 일 추가하기
async function addTodo() {
    const text = input.value.trim();
    if (!text) return;

    try {
        const response = await fetch('http://localhost:8080/api/todos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                title: text,
                completed: false
            })
        });

        if (response.ok) {
            input.value = '';
            loadTodos(); // 성공하면 서버에서 최신 목록 다시 불러오기
            input.focus();
        }
    } catch (error) {
        console.error("추가 실패:", error);
    }
}

// 3. 화면에 리스트 아이템 그리기 및 이벤트 연결
function createTodoElement(todo) {
    const li = document.createElement('li');
    if (todo.completed) li.classList.add('completed-state');

    li.innerHTML = `
        <div class="task-left">
            <input type="checkbox" class="complete-check" ${todo.completed ? 'checked' : ''}>
            <span class="task-text ${todo.completed ? 'completed' : ''}">${todo.title}</span>
            <input type="text" class="edit-input">
        </div>
        <div class="btn-group">
            <button class="edit-btn">수정</button>
            <button class="save-btn">저장</button>
            <button class="cancel-btn">취소</button>
            <button class="delete-btn">삭제</button>
        </div>
    `;

    const taskText = li.querySelector('.task-text');
    const editInput = li.querySelector('.edit-input');
    const editBtn = li.querySelector('.edit-btn');
    const saveBtn = li.querySelector('.save-btn');
    const cancelBtn = li.querySelector('.cancel-btn');
    const deleteBtn = li.querySelector('.delete-btn');
    const checkbox = li.querySelector('.complete-check');

    // [수정 모드 진입]
    editBtn.addEventListener('click', () => {
        li.classList.add('editing');
        editInput.value = taskText.innerText;

        // 핵심: 브라우저가 요소를 띄울 시간을 준 뒤 확실하게 포커스를 잡습니다.
        setTimeout(() => {
            editInput.focus();
            // 텍스트 맨 뒤에 커서가 오게 하고 싶다면 아래 한 줄을 추가하세요.
            const val = editInput.value;
            editInput.value = '';
            editInput.value = val;
        }, 10);
    });

    // [수정 내용 저장 - 서버 PUT 연동]
    saveBtn.addEventListener('click', async () => {
        const newTitle = editInput.value.trim();
        if (newTitle) {
            try {
                const response = await fetch(`http://localhost:8080/api/todos/${todo.id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        title: newTitle,
                        completed: checkbox.checked
                    })
                });

                if (response.ok) {
                    li.classList.remove('editing');
                    loadTodos(); // DB 반영 후 목록 갱신
                }
            } catch (error) {
                console.error("수정 실패:", error);
            }
        }
    });

    // 수정 입력창에서 엔터 치면 저장 버튼 클릭과 동일하게 작동
    editInput.addEventListener('keydown', (e) => {
        if (!e.isComposing && e.key === 'Enter') {
            saveBtn.click();
        }
        // ESC 누르면 취소되게 하고 싶다면?
        if (e.key === 'Escape') {
            cancelBtn.click();
        }
    });

    // [취소]
    cancelBtn.addEventListener('click', () => li.classList.remove('editing'));

    // [삭제 - 서버 DELETE 연동]
    deleteBtn.addEventListener('click', async () => {
        try {
            const response = await fetch(`http://localhost:8080/api/todos/${todo.id}`, {
                method: 'DELETE'
            });
            if (response.ok) loadTodos();
        } catch (error) {
            console.error("삭제 실패:", error);
        }
    });

    // [체크박스 - 서버 PUT 연동]
    checkbox.addEventListener('change', async () => {
        try {
            const response = await fetch(`http://localhost:8080/api/todos/${todo.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    title: todo.title,
                    completed: checkbox.checked
                })
            });

            if (response.ok) {
                taskText.classList.toggle('completed', checkbox.checked);
            }
        } catch (error) {
            console.error("체크 상태 업데이트 실패:", error);
        }
    });

    todoList.appendChild(li);
}

// 이벤트 연결
addBtn.addEventListener('click', addTodo);
input.addEventListener('keydown', (e) => {
    if (!e.isComposing && e.key === 'Enter') addTodo();
});

//http://localhost:8080/h2-console